#04.sep.2025..20:09

Design page of website.


Sectors:::

Code::

Front End: 

HTMl

CSS            -design

JavaScript     -client code (client.js)



Back End:

Basic path service

user database idenity (logons and saved data)    #0.5.sep.2025..19:24

security and auth

payment

support




Machine:

Cloudflared >> Nginx >> Guincorn >> wsgi.py






questions

whats is a database connector+cursor?


