#5.sep.2025

#username (id), password (encrypted), date of creation utc year/mounch/day/time,location (ip),browser,notes

import sqlite3,pandas # type: ignore


